const express = require('express');//Imports the Express library into the code
const mysql = require('mysql');//Imports the MySQL library for interacting for mysql
const app = express();
const port = 3000; //The port number where the server will listen 

app.use(express.static('.'));

// Database Connection
const db = mysql.createConnection({
    host: 'localhost',// The database server address
    user: 'root',//username
    password: '123456789',
    database: 'University'
});

db.connect(err => {
    if (err) throw err;
    console.log('MySQL Connected...');
});

// Fetch Students by Major
app.get('/api/students', (req, res) => {// url for retrieveing students
    const { Major } = req.query;// Accesses query parameters eli gaia mn user
    const query = `SELECT student_name, email FROM students WHERE Major = ?`;
    db.query(query, [Major], (err, results) => {//Executes the SQL query.
        if (err) {
            console.error('Error fetching students:', err);
            
        }
        res.json(results);//Sends the query results back as a JSON response
    });
});

// Get Classrooms for a Specific Building
app.get('/api/classrooms', (req, res) => {
    const { location } = req.query;
    const query = `SELECT classroom_name FROM classrooms WHERE location = ?`;
    db.query(query, [location], (err, results) => {
        if (err) {
            console.error('Error fetching classrooms:', err);
        }
        res.json(results);
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
